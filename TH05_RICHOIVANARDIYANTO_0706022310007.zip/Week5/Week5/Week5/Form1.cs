using System;
using System.Data;
using System.Reflection;
using System.Windows.Forms;

namespace Week5
{
    public partial class Form1 : Form
    {
        DataTable dtProdukSimpan = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();
        string idproduk = "";
        int idcategory = -1;
        bool delete = false;
        bool delete2 = false;
        public Form1()
        {
            InitializeComponent();


            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");

            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");

            dtProdukSimpan.Rows.Add("J001","Jas Hitam","100000","10","C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");


            dataGridView1.AllowUserToAddRows = false;
            dataGridView2.AllowUserToAddRows = false;

            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                string id = dtProdukSimpan.Rows[i][0].ToString();
                string nama = dtProdukSimpan.Rows[i][1].ToString();
                string category = dtProdukSimpan.Rows[i][4].ToString();
                string harga = dtProdukSimpan.Rows[i][2].ToString();
                string stok = dtProdukSimpan.Rows[i][3].ToString();

                dtProdukTampil.Rows.Add(id,nama,harga,stok,category);
            }

            dataGridView1.DataSource = dtProdukTampil;
            dataGridView2.DataSource = dtCategory;

            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                comboBox1.Items.Add(dtCategory.Rows[i][1].ToString());
                comboBox2.Items.Add(dtCategory.Rows[i][1].ToString());
            }

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            dataGridView2.ClearSelection();
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int index = dataGridView1.CurrentCell.RowIndex;
            delete = true;

            idproduk = dtProdukTampil.Rows[index][0].ToString();
            string nama = dtProdukTampil.Rows[index][1].ToString();
            string category = dtProdukTampil.Rows[index][4].ToString();
            string harga = dtProdukTampil.Rows[index][2].ToString();
            string stok = dtProdukTampil.Rows[index][3].ToString();

            textBox1.Text = nama;
            textBox3.Text = harga;
            textBox4.Text = stok;

            idcategory = -1;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][0].ToString() == category)
                {
                    comboBox1.SelectedIndex = i;
                    idcategory = i;
                    break;
                }
            }
        }


        private void dataGridView2_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int index = dataGridView2.CurrentCell.RowIndex;
            textBox2.Text = dtCategory.Rows[index][1].ToString();
            delete2 = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            comboBox2.Enabled = false;
            comboBox2.SelectedIndex = -1;

            dtProdukTampil.Clear();
            for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
            {
                string id = dtProdukSimpan.Rows[j][0].ToString();
                string nama = dtProdukSimpan.Rows[j][1].ToString();
                string category = dtProdukSimpan.Rows[j][4].ToString();
                string harga = dtProdukSimpan.Rows[j][2].ToString();
                string stok = dtProdukSimpan.Rows[j][3].ToString();

                dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            comboBox2.Enabled = true;
        }

        private void comboBox2_SelectionChangeCommitted(object sender, EventArgs e)
        {
            dtProdukTampil.Clear();

            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtCategory.Rows[comboBox2.SelectedIndex][0].ToString() == dtProdukSimpan.Rows[i][4].ToString())
                {
                    string id = dtProdukSimpan.Rows[i][0].ToString();
                    string nama = dtProdukSimpan.Rows[i][1].ToString();
                    string category = dtProdukSimpan.Rows[i][4].ToString();
                    string harga = dtProdukSimpan.Rows[i][2].ToString();
                    string stok = dtProdukSimpan.Rows[i][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox3.Text !="" && textBox4.Text != "" && idcategory != -1)
            {
                string hurufpertama = textBox1.Text.Substring(0, 1).ToUpper();
                int idcount = 0;
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString().Contains(hurufpertama + "00"))
                    {
                        idcount = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(3, 1));
                    }
                    else if (dtProdukSimpan.Rows[i][0].ToString().Contains(hurufpertama + "0"))
                    {
                        idcount = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(2, 2));
                    }
                    else if (dtProdukSimpan.Rows[i][0].ToString().Substring(0, 1) == hurufpertama)
                    {
                        idcount = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(1, 3));
                    }

                }
                string tid = "";
                idcount = idcount + 1;

                if (idcount < 10)
                {
                    tid = hurufpertama + "00" + idcount.ToString();
                }
                else if (idcount < 100)
                {
                    tid = hurufpertama + "0" + idcount.ToString();
                }
                else
                {
                    tid = hurufpertama + idcount.ToString();
                }
                string tnama = textBox1.Text;
                string tcategory = dtCategory.Rows[idcategory][0].ToString();
                string tharga = textBox3.Text;
                string tstok = textBox4.Text;

                dtProdukSimpan.Rows.Add(tid, tnama, tharga, tstok, tcategory);

                dtProdukTampil.Clear();
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    string id = dtProdukSimpan.Rows[j][0].ToString();
                    string nama = dtProdukSimpan.Rows[j][1].ToString();
                    string category = dtProdukSimpan.Rows[j][4].ToString();
                    string harga = dtProdukSimpan.Rows[j][2].ToString();
                    string stok = dtProdukSimpan.Rows[j][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }
                textBox1.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                comboBox1.SelectedIndex = -1;
                idcategory = -1;
            }
            else
            {
                MessageBox.Show("Requirement Unfufilled");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox3.Text != "" && textBox4.Text != "" && idcategory != -1)
            {
                int index = dataGridView1.CurrentCell.RowIndex;

                string idbarang = dtProdukTampil.Rows[index][0].ToString();
                string tnama = textBox1.Text;
                string tcategory = dtCategory.Rows[idcategory][0].ToString();
                string tharga = textBox3.Text;
                string tstok = textBox4.Text;

                for(int i = 0; i < dtProdukSimpan.Rows.Count ; i++)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString() == idbarang)
                    {
                        dtProdukSimpan.Rows[i][1] = tnama;
                        dtProdukSimpan.Rows[i][4] = tcategory;
                        dtProdukSimpan.Rows[i][2] = tharga;
                        dtProdukSimpan.Rows[i][3] = tstok;
                        break;
                    }
                }

                dtProdukTampil.Clear();
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    string id = dtProdukSimpan.Rows[j][0].ToString();
                    string nama = dtProdukSimpan.Rows[j][1].ToString();
                    string category = dtProdukSimpan.Rows[j][4].ToString();
                    string harga = dtProdukSimpan.Rows[j][2].ToString();
                    string stok = dtProdukSimpan.Rows[j][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }


                textBox1.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                comboBox1.SelectedIndex = -1;
                idcategory = -1;
            }
            else
            {
                MessageBox.Show("Requirement Unfufilled");
            }
        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            idcategory = comboBox1.SelectedIndex;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox3.Text != "" && textBox4.Text != "" && idcategory != -1 && delete)
            {
                int index = dataGridView1.CurrentCell.RowIndex;

                string idbarang = dtProdukTampil.Rows[index][0].ToString();

                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString() == idbarang)
                    {
                        dtProdukSimpan.Rows[i].Delete();
                        break;
                    }
                }

                dtProdukTampil.Clear();
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    string id = dtProdukSimpan.Rows[j][0].ToString();
                    string nama = dtProdukSimpan.Rows[j][1].ToString();
                    string category = dtProdukSimpan.Rows[j][4].ToString();
                    string harga = dtProdukSimpan.Rows[j][2].ToString();
                    string stok = dtProdukSimpan.Rows[j][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }


                textBox1.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                comboBox1.SelectedIndex = -1;
                idcategory = -1;
                delete = false;
            }
            else
            {
                MessageBox.Show("Please Select a row");
            }
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                bool adacategori = true;
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (textBox2.Text == dtCategory.Rows[i][1].ToString())
                    {
                        adacategori = false;
                        break;
                    }
                }
                if (adacategori)
                {
                    int idbaru = 0;
                    if (dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Length == 2)
                    {
                        idbaru = Convert.ToInt32(dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Substring(1, 1));
                    }
                    else if (dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Length == 3)
                    {
                        idbaru = Convert.ToInt32(dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Substring(1, 2));
                    }
                    else
                    {
                        idbaru = Convert.ToInt32(dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Substring(1, 3));
                    }
                    idbaru = idbaru + 1;
                    string idbarustr = "C" + idbaru.ToString();

                    dtCategory.Rows.Add(idbarustr, textBox2.Text);
                }
                else
                {
                    MessageBox.Show("Category already inputed");
                }

                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    comboBox1.Items.Add(dtCategory.Rows[i][1].ToString());
                    comboBox2.Items.Add(dtCategory.Rows[i][1].ToString());
                }

                comboBox2.SelectedIndex = -1;
                comboBox1.SelectedIndex = -1;

                dtProdukTampil.Clear();
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    string id = dtProdukSimpan.Rows[j][0].ToString();
                    string nama = dtProdukSimpan.Rows[j][1].ToString();
                    string category = dtProdukSimpan.Rows[j][4].ToString();
                    string harga = dtProdukSimpan.Rows[j][2].ToString();
                    string stok = dtProdukSimpan.Rows[j][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }

                textBox1.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                idcategory = -1;
            }
            else
            {
                MessageBox.Show("Please input a name");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "" && delete2)
            {
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    if (dtProdukSimpan.Rows[j][4].ToString() == dtCategory.Rows[dataGridView2.CurrentCell.RowIndex][0].ToString())
                    {
                        dtProdukSimpan.Rows[j].Delete();
                        j = 0;
                    }
                }


                dtCategory.Rows[dataGridView2.CurrentCell.RowIndex].Delete();

                comboBox2.SelectedIndex = -1;
                comboBox1.SelectedIndex = -1;
                dtProdukTampil.Clear();
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    string id = dtProdukSimpan.Rows[j][0].ToString();
                    string nama = dtProdukSimpan.Rows[j][1].ToString();
                    string category = dtProdukSimpan.Rows[j][4].ToString();
                    string harga = dtProdukSimpan.Rows[j][2].ToString();
                    string stok = dtProdukSimpan.Rows[j][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }

                comboBox1.Items.Clear();
                comboBox2.Items.Clear();
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    comboBox1.Items.Add(dtCategory.Rows[i][1].ToString());
                    comboBox2.Items.Add(dtCategory.Rows[i][1].ToString());
                }

                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                delete2 = false;
                idcategory = -1;
            }
            else
            {
                MessageBox.Show("Please select a row");
            }

        }
    }
}